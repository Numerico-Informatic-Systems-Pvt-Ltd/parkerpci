<?php 
/*plugin configs*/
$kz_db_version = '1.0.2';
$table_name = $wpdb->prefix . 'cwa';
$charset_collate = '';
?>